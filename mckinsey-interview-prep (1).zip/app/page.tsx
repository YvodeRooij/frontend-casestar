"use client"

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useUser } from '@/contexts/UserContext'
import { CompanyPath, CaseType, CaseResult, Skill, SkillCategory } from '@/types/journey'
import { CompanySelection } from '@/components/CompanySelection'
import { InteractiveTimeline } from '@/components/InteractiveTimeline'
import { NextStep } from '@/components/NextStep'
import { FocusedImprovement } from '@/components/FocusedImprovement'
import { KeySkillsCTA } from '@/components/KeySkillsCTA'

const mockMcKinseyData = {
  selectedPath: "McKinsey" as CompanyPath,
  caseResults: [
    {
      caseType: "personal_experience" as CaseType,
      passed: true,
      feedback: "Excellent job articulating your personal experiences. Your communication skills were outstanding.",
      improvementAreas: ["Provide more quantitative examples", "Strengthen problem structuring"],
      skills: [
        { category: "communication", level: "expert", score: 90 },
        { category: "problem_structuring", level: "developing", score: 65 },
        { category: "quantitative_analysis", level: "proficient", score: 75 },
        { category: "business_acumen", level: "developing", score: 60 },
        { category: "creativity", level: "proficient", score: 80 }
      ]
    },
    {
      caseType: "case_1" as CaseType,
      passed: false,
      feedback: "You demonstrated good creativity, but struggled with quantitative analysis and problem structuring.",
      improvementAreas: ["Enhance quantitative skills", "Practice breaking down complex problems"],
      skills: [
        { category: "communication", level: "proficient", score: 80 },
        { category: "problem_structuring", level: "novice", score: 40 },
        { category: "quantitative_analysis", level: "novice", score: 35 },
        { category: "business_acumen", level: "developing", score: 55 },
        { category: "creativity", level: "expert", score: 85 }
      ]
    }
  ],
  currentCase: "case_2" as CaseType,
  skillLevels: {
    problem_structuring: "developing",
    quantitative_analysis: "developing",
    business_acumen: "developing",
    communication: "proficient",
    creativity: "proficient"
  }
}

export default function Home() {
  const router = useRouter()
  const [selectedCompany, setSelectedCompany] = useState<CompanyPath | null>(null)
  const { userProgress, updateUserProgress } = useUser()

  const handleCompanySelect = (company: CompanyPath) => {
    setSelectedCompany(company)
    if (company === "McKinsey") {
      updateUserProgress(mockMcKinseyData)
    }
  }

  const handleStartNextStep = () => {
    if (userProgress.currentCase) {
      router.push(`/case/${userProgress.currentCase}`)
    }
  }

  const handlePracticeSkill = (skill: SkillCategory) => {
    router.push(`/skill-building/${skill}`)
  }

  const handleStartCase = (caseType: CaseType) => {
    router.push(`/case/${caseType}`)
  }

  if (!selectedCompany) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8 text-center text-primary">Consulting Interview Prep</h1>
        <CompanySelection onSelect={handleCompanySelect} />
      </div>
    )
  }

  const latestResult = userProgress.caseResults[userProgress.caseResults.length - 1]
  const canProceedToNextCase = latestResult ? latestResult.passed : true

  const overallSkills: Skill[] = userProgress.caseResults.flatMap(result => result.skills)
    .reduce((acc, skill) => {
      const existingSkill = acc.find(s => s.category === skill.category)
      if (existingSkill) {
        existingSkill.score = Math.round((existingSkill.score + skill.score) / 2)
      } else {
        acc.push({ ...skill })
      }
      return acc
    }, [] as Skill[])

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8 text-center text-primary">{selectedCompany} Interview Prep Journey</h1>
      
      <div className="space-y-8">
        <InteractiveTimeline 
          caseResults={userProgress.caseResults}
          currentCase={userProgress.currentCase}
          onStartCase={handleStartCase}
          onPracticeSkill={handlePracticeSkill}
        />
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <NextStep 
            currentCase={userProgress.currentCase}
            canProceed={canProceedToNextCase}
            onStart={handleStartNextStep}
          />
          {!canProceedToNextCase && latestResult && (
            <FocusedImprovement 
              latestResult={latestResult}
              onPractice={handlePracticeSkill}
            />
          )}
        </div>

        <KeySkillsCTA skills={overallSkills} onPractice={handlePracticeSkill} />
      </div>
    </div>
  )
}

