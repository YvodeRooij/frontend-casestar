"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { PracticeDojo } from "@/components/PracticeDojo"
import type { Message } from "@/types/practice"
import { motion } from "framer-motion"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ChevronDown } from "lucide-react"

const initialMessages: Message[] = [
  {
    id: "welcome",
    role: "interviewer",
    content:
      "Welcome to your case interview practice session. Today, we'll be discussing a market entry strategy for a tech company. Are you ready to begin?",
    contentType: "audio",
    audioUrl: "/audio/welcome.mp3",
  },
  {
    id: "context",
    role: "interviewer",
    content:
      "Our client is a leading smartphone manufacturer looking to enter the smartwatch market. They want to understand the market size, competition, and potential strategies for entry. Let's start with the market size. Here's some data on the global smartwatch market over the past few years.",
    contentType: "text",
  },
  {
    id: "market-size-chart",
    role: "interviewer",
    content: "Global Smartwatch Market Size",
    contentType: "chart",
    data: {
      type: "line",
      data: [
        { name: "2018", value: 15 },
        { name: "2019", value: 20 },
        { name: "2020", value: 25 },
        { name: "2021", value: 35 },
        { name: "2022", value: 45 },
      ],
    },
  },
  {
    id: "market-question",
    role: "interviewer",
    content:
      "Based on this data, what observations can you make about the smartwatch market? And how would you estimate the market size for 2023?",
    contentType: "audio",
    audioUrl: "/audio/market-question.mp3",
  },
  // Add more messages as needed to guide the case interview
]

const stages = [
  { label: "Problem", description: "Understand the client's situation and objectives" },
  { label: "Analysis", description: "Analyze market data and identify key insights" },
  { label: "Strategy", description: "Develop potential strategies based on the analysis" },
  { label: "Solution", description: "Present and defend your final recommendations" },
]

export default function CaseInterviewPreparation() {
  const [progress, setProgress] = useState(0)
  const router = useRouter()

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Case Interview: Smartwatch Market Entry</h1>
          <div className="flex items-center space-x-2">
            <Button variant="outline" onClick={() => router.push("/preparation")}>
              Back to Preparation
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon">
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => router.push("/")}>Go to Home</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold mb-4">Case Progress</h2>
            <div className="flex justify-between mb-2">
              {stages.map((stage, index) => (
                <div key={index} className="flex flex-col items-center">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${index <= progress / 25 ? "bg-primary text-primary-foreground" : "bg-muted"}`}
                  >
                    {index + 1}
                  </div>
                  <span className="text-sm mt-2">{stage.label}</span>
                </div>
              ))}
            </div>
            <div className="relative pt-1">
              <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-muted">
                <motion.div
                  className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-primary"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <PracticeDojo
          id="smartwatch-market-entry"
          title="Smartwatch Market Entry Strategy"
          initialMessages={initialMessages}
          practiceType="case-interview"
          onProgressUpdate={setProgress}
        />

        <div className="flex justify-end">
          <Button onClick={() => router.push("/preparation")} disabled={progress < 100}>
            {progress < 100 ? "Continue Practice" : "Complete Case"}
          </Button>
        </div>
      </div>
    </div>
  )
}

