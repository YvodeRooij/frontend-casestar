"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { PracticeDojo } from "@/components/PracticeDojo"
import type { Message } from "@/types/practice"

const sampleMarketData = {
  labels: ["2019", "2020", "2021", "2022", "2023"],
  datasets: [
    {
      label: "Market Size ($B)",
      data: [100, 120, 150, 200, 250],
    },
  ],
}

const initialMessages: Message[] = [
  {
    id: "welcome",
    role: "interviewer",
    content:
      "Welcome to the Business Frameworks practice session. Today, we'll work through a real case using various frameworks.",
    contentType: "text",
  },
  {
    id: "case-intro",
    role: "interviewer",
    content: "Let's analyze the electric vehicle market in Europe. Here's some market data to get us started.",
    contentType: "text",
  },
  {
    id: "market-data",
    role: "system",
    content: "EV Market Size Growth",
    contentType: "chart",
    data: {
      type: "line",
      data: sampleMarketData,
    },
  },
  {
    id: "market-share",
    role: "system",
    content: "Market Share by Manufacturer",
    contentType: "table",
    data: {
      headers: ["Manufacturer", "Market Share (%)", "YoY Growth (%)"],
      rows: [
        ["Tesla", 25, 15],
        ["Volkswagen", 20, 12],
        ["BMW", 15, 8],
        ["Mercedes", 12, 6],
        ["Others", 28, 10],
      ],
    },
  },
  {
    id: "framework-prompt",
    role: "interviewer",
    content: "Using this data, let's conduct a SWOT analysis for Tesla in the European market.",
    contentType: "framework",
    data: {
      type: "swot",
      context: "Tesla in European EV Market",
    },
  },
  {
    id: "calculation",
    role: "interviewer",
    content: "Based on the market share data, what would be Tesla's revenue in 2023 if the total market size is $250B?",
    contentType: "calculation",
    data: {
      solution: 62.5,
      hints: [
        "Consider Tesla's market share percentage",
        "Multiply the total market size by the market share (as a decimal)",
      ],
    },
    feedback: {
      correct: "Excellent! $62.5B is correct. You correctly calculated 25% of $250B.",
      incorrect:
        "Not quite. Remember to convert the market share percentage to a decimal (25% = 0.25) and multiply by the total market size ($250B).",
    },
  },
]

export default function FrameworksPreparation() {
  const [progress, setProgress] = useState(0)
  const router = useRouter()

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Business Frameworks Practice</h1>
          <Button variant="outline" onClick={() => router.push("/")}>
            Back to Overview
          </Button>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Progress</span>
            <span className="text-sm text-muted-foreground">{progress}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <PracticeDojo
          id="frameworks"
          title="Business Frameworks"
          initialMessages={initialMessages}
          practiceType="qualitative"
          onProgressUpdate={setProgress}
        />

        <div className="flex justify-end">
          <Button onClick={() => router.push("/")} disabled={progress < 100}>
            {progress < 100 ? "Complete All Sections" : "Return to Case Prep"}
          </Button>
        </div>
      </div>
    </div>
  )
}

