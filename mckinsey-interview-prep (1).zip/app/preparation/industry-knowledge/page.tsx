import { PreparationArea } from '@/components/PreparationArea'

const content = {
  text: "Staying updated on industry trends is crucial for consultants. Regularly read publications like The Economist, Wall Street Journal, and industry-specific journals. Pay attention to emerging technologies, market disruptions, and regulatory changes across various sectors. This knowledge will help you provide more insightful recommendations during case interviews.",
  quiz: {
    question: "Which of these is NOT a current trend in the tech industry?",
    options: ["Artificial Intelligence", "Blockchain", "Floppy Disk Storage", "Internet of Things"],
    correctAnswer: "Floppy Disk Storage"
  },
  exercise: {
    instruction: "Research and summarize a recent development in an industry of your choice. Explain its potential impact on businesses in that sector.",
    hint: "Consider recent news in industries like healthcare, finance, or technology. Think about how this development might affect companies' strategies, operations, and competitive landscape."
  }
}

export default function IndustryKnowledgePreparation() {
  return (
    <PreparationArea
      id="industryTrends"
      title="Industry Knowledge"
      content={content}
    />
  )
}

