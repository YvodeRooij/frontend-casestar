import { PreparationArea } from '@/components/PreparationArea'

const content = {
  text: "Structured communication is key in consulting. The Pyramid Principle, developed by Barbara Minto, is a widely used method for presenting ideas clearly and persuasively. Start with your main point or recommendation, then provide supporting arguments. This top-down approach ensures your message is clear, logical, and easy to follow.",
  quiz: {
    question: "What is the first step in the Pyramid Principle?",
    options: ["Provide supporting arguments", "Start with details", "Begin with the conclusion", "List all options"],
    correctAnswer: "Begin with the conclusion"
  },
  exercise: {
    instruction: "Structure a response to the question: 'Why should our company expand into the Asian market?' Use the Pyramid Principle.",
    hint: "Start with your recommendation, then provide 2-3 supporting arguments. Each argument should be backed by evidence or reasoning."
  }
}

export default function StructuredCommunicationPreparation() {
  return (
    <PreparationArea
      id="structuredResponses"
      title="Structured Communication"
      content={content}
    />
  )
}

