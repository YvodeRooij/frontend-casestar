import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Case Interview Practice V3",
  description: "Enhanced case interview practice platform with real-time feedback and AI-powered coaching",
}

export default function V3Layout({
  children,
}: {
  children: React.ReactNode
}) {
  return <div className="min-h-screen">{children}</div>
}

