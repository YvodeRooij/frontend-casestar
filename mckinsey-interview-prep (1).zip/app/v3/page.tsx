import { PreparationOverview } from "@/components/PreparationOverview"

export default function V3Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <PreparationOverview />
    </div>
  )
}

