"use client"

import { PreparationArea } from "@/components/PreparationArea"

const content = {
  text: "Master key business frameworks to structure your approach to case interviews.",
  quiz: {
    question: "Which framework would you use to analyze a company's competitive position?",
    options: ["SWOT Analysis", "Porter's Five Forces", "4Ps of Marketing", "BCG Matrix"],
    correctAnswer: "Porter's Five Forces",
  },
  exercise: {
    instruction:
      "Apply the MECE principle to categorize the following list of fruits: Apple, Banana, Orange, Grape, Watermelon, Strawberry, Blueberry, Mango.",
    hint: "Consider categories like color, size, or type of fruit.",
  },
}

export default function FrameworksPreparation() {
  return <PreparationArea id="frameworks" title="Business Frameworks" content={content} />
}

