"use client"

import { PreparationArea } from "@/components/PreparationArea"

const content = {
  text: "Stay updated on industry trends and market dynamics.",
  quiz: {
    question: "Which of these is NOT a current trend in the tech industry?",
    options: ["Artificial Intelligence", "Blockchain", "Floppy Disk Storage", "Internet of Things"],
    correctAnswer: "Floppy Disk Storage",
  },
  exercise: {
    instruction: "Research and summarize a recent development in an industry of your choice.",
    hint: "Consider recent news in industries like healthcare, finance, or technology.",
  },
}

export default function IndustryKnowledgePreparation() {
  return <PreparationArea id="industryTrends" title="Industry Knowledge" content={content} />
}

