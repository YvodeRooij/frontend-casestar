"use client"

import { PreparationArea } from "@/components/PreparationArea"

const content = {
  text: "Mental math is crucial in consulting interviews for quick estimations and data analysis.",
  quiz: {
    question: "What is 15% of 80?",
    options: ["10", "12", "15", "18"],
    correctAnswer: "12",
  },
  exercise: {
    instruction: "Estimate the result of 38 x 42 without using a calculator.",
    hint: "Try rounding to 40 x 40 and then adjusting for the difference.",
  },
}

export default function MentalMathPreparation() {
  return <PreparationArea id="mentalMath" title="Mental Math" content={content} />
}

