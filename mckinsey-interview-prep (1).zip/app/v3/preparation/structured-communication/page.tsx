"use client"

import { PreparationArea } from "@/components/PreparationArea"

const content = {
  text: "Learn to communicate your thoughts clearly and concisely using structured approaches.",
  quiz: {
    question: "What is the first step in the Pyramid Principle?",
    options: ["Start with details", "Begin with the conclusion", "List all options", "Describe the problem"],
    correctAnswer: "Begin with the conclusion",
  },
  exercise: {
    instruction: "Structure a response to the question: 'Why should our company expand into the Asian market?'",
    hint: "Use the Pyramid Principle: Start with your recommendation, then provide 2-3 supporting arguments.",
  },
}

export default function StructuredCommunicationPreparation() {
  return <PreparationArea id="structuredCommunication" title="Structured Communication" content={content} />
}

