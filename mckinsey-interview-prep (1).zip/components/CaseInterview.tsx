import { useUser } from "@/contexts/UserContext"
import type { CaseType, CaseResult } from "@/types/journey"
import { PreparationJourney } from "./PreparationJourney"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function CaseInterview({ caseType }: { caseType: CaseType }) {
  const { userProgress, addCaseResult, updateSkillLevel } = useUser()
  const [isCompleted, setIsCompleted] = useState(false)
  const [feedback, setFeedback] = useState("")
  const [passed, setPassed] = useState(false)
  const [skills, setSkills] = useState<Skill[]>([])

  const handleSubmit = (result: CaseResult) => {
    addCaseResult(result)
    setIsCompleted(true)
    setFeedback(result.feedback)
    setPassed(result.passed)
    setSkills(result.skills)
  }

  if (isCompleted) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Case Interview Results</CardTitle>
        </CardHeader>
        <CardContent>
          <p>Feedback: {feedback}</p>
          <p>Passed: {passed ? "Yes" : "No"}</p>
          {skills.map((skill) => (
            <p key={skill.category}>
              {skill.category}: {skill.level}
            </p>
          ))}
          <Button onClick={() => window.location.reload()}>Next Case</Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div>
      <h1>{caseType} Case Interview</h1>
      <PreparationJourney caseType={caseType} onStartCase={() => {}} />{" "}
      {/* Placeholder, replace with actual functionality */}
      <Button
        onClick={() =>
          handleSubmit({ caseType, passed: true, feedback: "Great job!", improvementAreas: [], skills: [] })
        }
      >
        Submit
      </Button>
    </div>
  )
}

