"use client"

import React, { createContext, useContext, useState, useEffect } from 'react'
import { UserProgress, CaseResult, SkillCategory, SkillLevel, CompanyPath, CaseType } from '@/types/journey'

interface UserContextType {
  userProgress: UserProgress
  updateUserProgress: (newProgress: Partial<UserProgress>) => void
  addCaseResult: (result: CaseResult) => void
  updateSkillLevel: (category: SkillCategory, level: SkillLevel) => void
  setSelectedPath: (path: CompanyPath) => void
  getNextCase: () => CaseType | null
}

const defaultUserProgress: UserProgress = {
  selectedPath: null,
  caseResults: [],
  currentCase: null,
  skillLevels: {
    problem_structuring: "novice",
    quantitative_analysis: "novice",
    business_acumen: "novice",
    communication: "novice",
    creativity: "novice"
  }
}

const UserContext = createContext<UserContextType | undefined>(undefined)

export function UserProvider({ children }: { children: React.ReactNode }) {
  const [userProgress, setUserProgress] = useState<UserProgress>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('userProgress')
      return saved ? JSON.parse(saved) : defaultUserProgress
    }
    return defaultUserProgress
  })

  useEffect(() => {
    localStorage.setItem('userProgress', JSON.stringify(userProgress))
  }, [userProgress])

  const updateUserProgress = (newProgress: Partial<UserProgress>) => {
    setUserProgress(prev => ({ ...prev, ...newProgress }))
  }

  const addCaseResult = (result: CaseResult) => {
    setUserProgress(prev => ({
      ...prev,
      caseResults: [...prev.caseResults, result],
      currentCase: getNextCase()
    }))
  }

  const updateSkillLevel = (category: SkillCategory, level: SkillLevel) => {
    setUserProgress(prev => ({
      ...prev,
      skillLevels: { ...prev.skillLevels, [category]: level }
    }))
  }

  const setSelectedPath = (path: CompanyPath) => {
    setUserProgress(prev => ({
      ...prev,
      selectedPath: path,
      currentCase: "personal_experience"
    }))
  }

  const getNextCase = (): CaseType | null => {
    const caseOrder: CaseType[] = ["personal_experience", "case_1", "case_2", "case_3", "final_round"]
    const currentIndex = caseOrder.indexOf(userProgress.currentCase as CaseType)
    
    if (currentIndex < caseOrder.length - 1) {
      return caseOrder[currentIndex + 1]
    }
    
    return null // All cases completed
  }

  return (
    <UserContext.Provider value={{ 
      userProgress, 
      updateUserProgress, 
      addCaseResult, 
      updateSkillLevel,
      setSelectedPath,
      getNextCase
    }}>
      {children}
    </UserContext.Provider>
  )
}

export const useUser = () => {
  const context = useContext(UserContext)
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider')
  }
  return context
}

