export type CompanyPath = "McKinsey" | "BCG" | "Bain" | "General"

export type CaseType = "personal_experience" | "case_1" | "case_2" | "case_3" | "final_round"

export type SkillCategory = "problem_structuring" | "quantitative_analysis" | "business_acumen" | "communication" | "creativity"

export type SkillLevel = "novice" | "developing" | "proficient" | "expert"

export interface Skill {
  category: SkillCategory
  level: SkillLevel
  score: number
}

export interface CaseResult {
  caseType: CaseType
  passed: boolean
  feedback: string
  improvementAreas: string[]
  skills: Skill[]
}

export interface UserProgress {
  selectedPath: CompanyPath
  caseResults: CaseResult[]
  currentCase: CaseType | null
  skillLevels: Record<SkillCategory, SkillLevel>
}

