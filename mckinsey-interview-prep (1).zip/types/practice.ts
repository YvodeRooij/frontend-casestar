export type MessageContentType =
  | "text"
  | "chart"
  | "table"
  | "calculation"
  | "framework"
  | "quiz"
  | "exercise"
  | "data"
  | "feedback"
  | "audio"

export type PracticeType = "quantitative" | "qualitative" | "communication" | "case-interview"

export interface ChartData {
  type: "bar" | "line" | "pie"
  data: any
  options?: any
}

export interface TableData {
  headers: string[]
  rows: (string | number)[][]
}

export interface CalculationExercise {
  problem: string
  solution: number
  hints: string[]
}

export interface FrameworkExercise {
  type: "porter" | "swot" | "bcg" | "4p" | "custom"
  context: string
  template?: any
}

export interface Message {
  id: string
  role: "interviewer" | "user" | "system"
  content: string
  contentType: MessageContentType
  data?: ChartData | TableData | CalculationExercise | FrameworkExercise
  options?: string[]
  correctAnswer?: string
  hints?: string[]
  feedback?: {
    correct: string
    incorrect: string
  }
  audioUrl?: string
}

export interface PracticeState {
  messages: Message[]
  progress: number
  currentStep: number
  answers: Record<string, any>
  scratchpad: string
  calculations: string[]
  frameworks: Record<string, any>
  isAiSpeaking: boolean
  isUserSpeaking: boolean
}

