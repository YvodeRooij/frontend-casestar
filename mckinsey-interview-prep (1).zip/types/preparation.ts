export interface Message {
  id: string
  role: "system" | "user"
  content: string
  type?: "text" | "quiz" | "exercise" | "feedback"
  options?: string[]
  correctAnswer?: string
  completed?: boolean
}

export interface PreparationState {
  messages: Message[]
  progress: number
  currentStep: number
  quizAnswers: Record<string, string>
  exerciseCompleted: boolean
}

